INSERT INTO users(username,password,enabled) values('fasal','f',true);
INSERT INTO users(username,password,enabled) values('ragoo','r',true);

INSERT INTO authorities(username,authority) values('ragoo','ROLE_ADMIN');
INSERT INTO authorities(username,authority) values('fasal','ROLE_USER');
