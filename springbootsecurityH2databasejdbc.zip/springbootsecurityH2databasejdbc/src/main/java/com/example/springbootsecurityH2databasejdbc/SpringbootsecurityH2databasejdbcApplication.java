package com.example.springbootsecurityH2databasejdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootsecurityH2databasejdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootsecurityH2databasejdbcApplication.class, args);
	}

}
