package com.example.springbootsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
