package com.example.springbootsecurity.authenticationmanager;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter
{
	/*Builder Pattern chain 'and' we can n use n number of user*/
	/*Authentication Based on inmemory Authentication*/
	
    @Override 
	protected void configure(AuthenticationManagerBuilder auth) throws Exception 
	{
    	//based on In MemoryDataBase
		auth.inMemoryAuthentication()
		.withUser("fasal")
		.password("f")
		.roles("USER")
		.and()
		.withUser("ragoo")
		.password("r")
		.roles("ADMIN");
	}
    
    /*
     * if we want our password in encoded password HASED PASSWORD
     */
    
    @Bean
    public PasswordEncoder getMyEncodePassword() 
    {
      return NoOpPasswordEncoder.getInstance();
    }
    
	/*
	 * Authorization
	 * 
	 * we need override httpsecurity
	 * 
	 * */
    @Override
    protected void configure(HttpSecurity http) throws Exception
    {
    	http.authorizeRequests()
    	
    	 /*ALL PATH -> WILD CARD 
		 .antMatchers("/**").hasAnyRole("USER","ADMIN"); 
		 */
    	
		/* 
		 * TO MAKE OUR REQUEST PUBLIC
		 * .antMatchers("/","static/css","static/js").permitAll()
		  */
    	
    	 .antMatchers("/admin").hasRole("ADMIN")
    	 .antMatchers("/user").hasAnyRole("USER","ADMIN")
    	 .antMatchers("/").permitAll()
		 .and().formLogin();
        
		
	}
    
}
