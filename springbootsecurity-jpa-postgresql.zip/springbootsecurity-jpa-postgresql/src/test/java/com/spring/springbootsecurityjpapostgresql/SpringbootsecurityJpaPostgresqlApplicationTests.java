package com.spring.springbootsecurityjpapostgresql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootsecurityJpaPostgresqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
