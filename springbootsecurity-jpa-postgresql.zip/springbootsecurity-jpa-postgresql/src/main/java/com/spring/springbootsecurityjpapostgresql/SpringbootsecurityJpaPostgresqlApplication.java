package com.spring.springbootsecurityjpapostgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.spring.springbootsecurityjpapostgresql.service.MySecurityJPARepository;

@SpringBootApplication
@EnableJpaRepositories(basePackageClasses = MySecurityJPARepository.class)
public class SpringbootsecurityJpaPostgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootsecurityJpaPostgresqlApplication.class, args);
	}
																																																																																																																																																																				
}
																																																																																																																																		