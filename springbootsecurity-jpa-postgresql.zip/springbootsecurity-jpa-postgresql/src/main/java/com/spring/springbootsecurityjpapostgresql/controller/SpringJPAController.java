package com.spring.springbootsecurityjpapostgresql.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringJPAController 
{
	
	@RequestMapping(path = "/",method = RequestMethod.GET)
	public String getWelcomeMsg() 
	{
		return ("<h2>welcome</h2>");
	}
	
	@RequestMapping(path = "/user",method = RequestMethod.GET)
	public String getWelcomeUserMsg() 
	{
		return ("<h2>welcome user</h2>");
	}
	
	@RequestMapping(path = "/admin",method = RequestMethod.GET)
	public String getWelcomeAdminMsg() 
	{ 
		return ("<h2>welcome admin</h2>");
	}
	
	
	

}
