package com.spring.springbootsecurityjpapostgresql.service;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.spring.springbootsecurityjpapostgresql.model.User;

@Repository
public interface MySecurityJPARepository extends JpaRepository<User, Integer>
{
   Optional<User> findByUsername(String username);
	
}
